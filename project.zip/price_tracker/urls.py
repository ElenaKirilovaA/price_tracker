"""
URL configuration for price_tracker project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

from common.views import custom_404
from price_tracker.settings import MEDIA_URL





urlpatterns = [
       path('admin/', admin.site.urls),
    path('', include('alert.urls')),

    path('catalog/', include('catalog.urls')),
    path('product/', include('product.urls')),
]


if settings.DEBUG:
    urlpatterns += static(MEDIA_URL, document_root=settings.MEDIA_ROOT)

handler404 = custom_404
